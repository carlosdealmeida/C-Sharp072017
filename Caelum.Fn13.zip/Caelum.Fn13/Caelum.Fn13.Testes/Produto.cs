﻿namespace Caelum.Fn13.Testes
{
    internal class Produto
    {
        public string Categoria { get; set; }
        public string Descricao { get; set; }
        public int Id { get; set; }
        public double PrecoUnitario { get; set; }

        public override bool Equals(object obj)
        {
            if ( !(obj is Produto))
            {
                return false;
            }

            if (obj == null) {
                return false;
            }

            Produto outra = (Produto)obj;

            return ((this.Id == outra.Id)
                && (this.Categoria == outra.Categoria)
                && (this.Descricao == outra.Descricao)
                && (this.PrecoUnitario == outra.PrecoUnitario));
        }

        public override int GetHashCode()
        {
            var hashID = Id.GetHashCode();
            var hashCategoria = Categoria.GetHashCode();
            var hashDescricao = Descricao.GetHashCode();
            var hashPrecoUnitario = PrecoUnitario.GetHashCode();

            var somaHash = hashID + hashCategoria + hashDescricao + hashPrecoUnitario;

            return somaHash;
        }
    }

}