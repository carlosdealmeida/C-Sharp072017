﻿using System;

namespace Caelum.Fn13.Testes
{
    internal class ProdutoInexistenteException : Exception
    {
    }
}