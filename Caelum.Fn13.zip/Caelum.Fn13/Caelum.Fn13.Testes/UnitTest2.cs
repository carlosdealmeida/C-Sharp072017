﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Caelum.Fn13.Testes
{
    [TestClass]
    public class NotaFiscalTeste
    {
        [TestMethod]
        public void NotaFiscalAdiconaProdutos()
        {
            var nf = new NotaFiscal();

            var p1 = new Produto();

            nf.adicionaProduto(p1);
            Assert.IsTrue(nf.ListaProdutos.Count == 1);
        }

        [TestMethod]
        public void NotaFiscalRemove1Produtos()
        {
            var nf = new NotaFiscal();

            var p1 = new Produto();

            nf.adicionaProduto(p1);
            nf.RemoveProduto(p1);

            Assert.IsTrue(nf.ListaProdutos.Count == 0);
        }

        [TestMethod()]
        [ExpectedException(typeof(ProdutoInexistenteException))]
        public void NotaFiscalRemoveProdutoQueNaoExiste()
        {
            var nf = new NotaFiscal();

            var p1 = new Produto();

            nf.RemoveProduto(p1);

            Assert.IsTrue(nf.ListaProdutos.Count == 0);
        }   
    }
}
