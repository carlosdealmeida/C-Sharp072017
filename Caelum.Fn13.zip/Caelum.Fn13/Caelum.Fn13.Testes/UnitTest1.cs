﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Caelum.Fn13.Testes
{
    [TestClass]
    public class ProdutoTestes
    {
        [TestMethod]
        public void ProdutoPossuiIdDescricaoCategoriaEPreco()
        {
            var p = new Produto
            {
                Id = 1,
                Descricao = "Laranja",
                Categoria = "Bebida",
                PrecoUnitario = 1.99
            };

            Assert.AreEqual(1, p.Id);
        }

        [TestMethod]
        public void ProdutosIguaisEntaoEqualsEhTrue()
        {
            var p1 = new Produto
            {
                Id = 1,
                Descricao = "Laranja",
                Categoria = "Bebida",
                PrecoUnitario = 1.99
            };

            var p2 = new Produto
            {
                Id = 1,
                Descricao = "Laranja",
                Categoria = "Bebida",
                PrecoUnitario = 1.99
            };

            Assert.IsTrue(p1.Equals(p2));
        }

        [TestMethod]
        public void TestaProdutoENulo()
        {
            var p1 = new Produto
            {
                Id = 1,
                Descricao = "Laranja",
                Categoria = "Bebida",
                PrecoUnitario = 1.99
            };

            Produto p2 = null;

            Assert.IsTrue( !(p1.Equals(p2)) );
        }

        [TestMethod]
        public void TestaProdutoIgualOutrosObjs()   
        {
            var p1 = new Produto
            {
                Id = 1,
                Descricao = "Laranja",
                Categoria = "Bebida",
                PrecoUnitario = 1.99
            };

            String p2 = "";

            Assert.IsTrue( !(p1.Equals(p2) ));

        }

        [TestMethod]
        public void TestaProdutoGetHashCode()
        {
            var p1 = new Produto
            {
                Id = 1,
                Descricao = "Laranja",
                Categoria = "Bebida",
                PrecoUnitario = 1.99
            };

            var p2 = new Produto
            {
                Id = 1,
                Descricao = "Limao",
                Categoria = "Bebida",
                PrecoUnitario = 1.99
            };

            Assert.AreNotEqual(p1.GetHashCode(),p2.GetHashCode());

        }

        [TestMethod]
        public void TesteNovoProduto()
        {
            var p1 = new Produto
            {
                Descricao = "Laranja",
                Categoria = "Bebida",
                PrecoUnitario = 1.99
            };

            var p2 = new Produto
            {
                Descricao = "Laranja",
                Categoria = "Bebida",
                PrecoUnitario = 1.99
            };

            Assert.AreEqual(p1.GetHashCode(), p2.GetHashCode());

        }

    }
}
