﻿using System;
using System.Collections.Generic;

namespace Caelum.Fn13.Testes
{
    internal class NotaFiscal
    {
        public List<Produto> ListaProdutos;

        public NotaFiscal()
        {
            ListaProdutos = new List<Produto>();
            
        }

        internal bool adicionaProduto(Produto p)
        {
            ListaProdutos.Add(p);

            return true;
        }

        internal void RemoveProduto(Produto p1)
        {
            if (!ListaProdutos.Remove(p1))
            {
                throw new ProdutoInexistenteException();
            }
        }
    }
}